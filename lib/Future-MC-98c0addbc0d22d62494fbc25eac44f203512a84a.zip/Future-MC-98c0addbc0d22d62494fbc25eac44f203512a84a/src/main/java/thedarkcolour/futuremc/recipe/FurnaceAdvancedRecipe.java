package thedarkcolour.futuremc.recipe;

public class FurnaceAdvancedRecipe {
}