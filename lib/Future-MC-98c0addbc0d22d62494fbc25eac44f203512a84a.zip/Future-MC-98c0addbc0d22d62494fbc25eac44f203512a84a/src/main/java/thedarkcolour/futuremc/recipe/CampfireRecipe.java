package thedarkcolour.futuremc.recipe;

public class CampfireRecipe {
}