package thedarkcolour.futuremc.item;

public class ItemScaffold {//extends ItemBlock {

}