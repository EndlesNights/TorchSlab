# Future MC [![](http://cf.way2muchnoise.eu/full_310059_downloads.svg)](https://minecraft.curseforge.com/projects/future-mc) [![](https://cf.way2muchnoise.eu/packs/310059.svg)](https://www.curseforge.com/minecraft/mc-mods/future-mc/relations/dependents?filter-related-dependents=6) [![](http://cf.way2muchnoise.eu/versions/For%20MC_310059_all.svg)](https://minecraft.curseforge.com/projects/future-mc)
Adds blocks from previous versions. This mod is very incomplete, I will add more as I continue to work on it.

If you would like to see incomplete features of the mod, create a file called "debug_future_mc.txt" in your .minecraft folder.
Incomplete features are Scaffolding, Loom functionality, and Globe banners.

Just a quick reminder that this project is under an All Rights Reserved license.
